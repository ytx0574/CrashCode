//
//  JPlaceholderTextView.h
//  JPlaceholderTextView
//
//  Created by Fanny on 10/13/15.
//  Copyright (c) 2015 Fanny~. All rights reserved.
//
//

#import <UIKit/UIKit.h>

@interface JPlaceholderTextView : UITextView

@property (nonatomic, copy) NSString *placeholder;

@end

//
//  JPlaceholder.h
//  JPlaceholder
//
//  Created by Fanny on 10/13/15.
//  Copyright (c) 2015 Fanny~. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JPlaceholderTextView.h"

//! Project version number for JPlaceholder.
FOUNDATION_EXPORT double JPlaceholderVersionNumber;

//! Project version string for JPlaceholder.
FOUNDATION_EXPORT const unsigned char JPlaceholderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JPlaceholder/PublicHeader.h>


